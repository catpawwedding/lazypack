﻿# ============================================================
#  影片轉檔 H264（喵爸專用）PowerShell 版
#  由 convert-h264.bat 啟動（拖檔進去）
#  對中文檔名 / 路徑穩定
# ============================================================
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 工具包資料夾裡若有 setup.bat 抓下來的 ffmpeg.exe，優先用它（免裝、免設 PATH）
$env:Path = "$PSScriptRoot;" + $env:Path

$ffmpeg = (Get-Command ffmpeg -ErrorAction SilentlyContinue)
if (-not $ffmpeg) {
    Write-Host "[錯誤] 找不到 ffmpeg，請先安裝 ffmpeg。" -ForegroundColor Red
    Read-Host "按 Enter 關閉"
    exit
}

if ($args.Count -eq 0) {
    Write-Host "用法：把「影片檔」或「資料夾」拖到 convert-h264.bat 上放開即可。"
    Read-Host "按 Enter 關閉"
    exit
}

$exts = '.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v'
$targets = @()

foreach ($p in $args) {
    if (Test-Path -LiteralPath $p -PathType Container) {
        # 資料夾 → 收集裡面的影片
        $targets += Get-ChildItem -LiteralPath $p -File | Where-Object { $exts -contains $_.Extension.ToLower() }
    }
    elseif (Test-Path -LiteralPath $p -PathType Leaf) {
        $targets += Get-Item -LiteralPath $p
    }
}

if ($targets.Count -eq 0) {
    Write-Host "沒有找到可以轉的影片檔（支援 mp4/mkv/webm/mov/avi/m4v）。"
    Read-Host "按 Enter 關閉"
    exit
}

$done = 0; $skip = 0; $fail = 0

foreach ($f in $targets) {
    $outDir = Join-Path $f.DirectoryName '轉好H264'
    if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }
    $outFile = Join-Path $outDir ($f.BaseName + '.mp4')

    if (Test-Path -LiteralPath $outFile) {
        Write-Host "[跳過] 已存在：$($f.Name)" -ForegroundColor Yellow
        $skip++
        continue
    }

    Write-Host ""
    Write-Host "=== 轉檔中：$($f.Name) ===" -ForegroundColor Cyan
    & ffmpeg -y -i $f.FullName -c:v libx264 -crf 20 -preset medium -pix_fmt yuv420p -c:a aac -b:a 192k $outFile
    if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $outFile)) {
        Write-Host "[完成] $($f.Name)  ->  $outDir\" -ForegroundColor Green
        $done++
    } else {
        Write-Host "[失敗] $($f.Name)" -ForegroundColor Red
        $fail++
    }
}

Write-Host ""
Write-Host "============================================================"
Write-Host " 全部處理完畢：成功 $done 支，跳過 $skip 支，失敗 $fail 支"
Write-Host " 轉好的檔在各來源資料夾的「轉好H264」裡"
Write-Host "============================================================"
Read-Host "按 Enter 關閉"
