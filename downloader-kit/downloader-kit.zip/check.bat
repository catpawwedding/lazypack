@echo off
REM Environment check - screenshot this window when asking for help (ASCII only)
title Toolkit Check
cd /d "%~dp0"
set PATH=%~dp0;%PATH%
echo ==========================================
echo   Toolkit Environment Check
echo ==========================================
echo.
echo --- [1] Python ---
python -c "import sys; print('PYTHON OK  ' + sys.version)" 2>nul || echo PYTHON MISSING (or only the fake Store shortcut) - run setup.bat
echo.
echo --- [2] Packages ---
python -c "import yt_dlp; print('yt-dlp          OK')" 2>nul || echo yt-dlp          MISSING - run setup.bat
python -c "import faster_whisper; print('faster-whisper  OK')" 2>nul || echo faster-whisper  MISSING - run setup.bat
python -c "import opencc; print('opencc          OK')" 2>nul || echo opencc          MISSING - run setup.bat
python -c "import truststore; print('truststore      OK')" 2>nul || echo truststore      MISSING - run setup.bat
echo.
echo --- [3] ffmpeg ---
ffmpeg -version 2>nul | findstr /B "ffmpeg version" || echo FFMPEG MISSING - run setup.bat
echo.
echo --- [4] Downloader port 8765 ---
netstat -ano | findstr ":8765" | findstr "LISTENING"
echo (lines above = a downloader is already running; nothing = free)
echo.
echo ==========================================
echo   Screenshot this whole window and send it.
echo ==========================================
pause
