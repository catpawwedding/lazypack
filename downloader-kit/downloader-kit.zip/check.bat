@echo off
chcp 65001 >nul
title Self check
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\_check.ps1"
