﻿# 拖曳影片進來 → 轉成通用 H264 mp4（由 convert-h264.bat 呼叫）
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$kit = $PSScriptRoot
$rt  = Join-Path $kit 'runtime'
$env:Path = "$rt;$kit;" + $env:Path

if (-not (Get-Command ffmpeg -ErrorAction SilentlyContinue)) {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    [System.Windows.Forms.MessageBox]::Show(
        "還沒安裝完成喔。`n`n請先點兩下同一個資料夾裡的`n【setup.bat】，`n等它跳出「安裝完成」再回來用。",
        '請先安裝', 0, 48) | Out-Null
    exit 1
}

if ($args.Count -eq 0) {
    Write-Host ''
    Write-Host '  用法：把影片檔或整個資料夾「拖」到 convert-h264.bat 上面放開。'
    Write-Host ''
    Read-Host '按 Enter 關閉'
    exit
}

$exts = '.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v'
$targets = @()
foreach ($p in $args) {
    if (Test-Path -LiteralPath $p -PathType Container) {
        $targets += Get-ChildItem -LiteralPath $p -File | Where-Object { $exts -contains $_.Extension.ToLower() }
    } elseif (Test-Path -LiteralPath $p -PathType Leaf) {
        $targets += Get-Item -LiteralPath $p
    }
}
if ($targets.Count -eq 0) {
    Write-Host '沒有找到可以轉的影片檔（支援 mp4/mkv/webm/mov/avi/m4v）。'
    Read-Host '按 Enter 關閉'
    exit
}

$done = 0; $skip = 0; $fail = 0
foreach ($f in $targets) {
    $outDir = Join-Path $f.DirectoryName '轉好H264'
    if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }
    $outFile = Join-Path $outDir ($f.BaseName + '.mp4')
    if (Test-Path -LiteralPath $outFile) {
        Write-Host "[跳過] 已存在：$($f.Name)" -ForegroundColor Yellow
        $skip++; continue
    }
    Write-Host ''
    Write-Host "=== 轉檔中：$($f.Name) ===" -ForegroundColor Cyan
    & ffmpeg -y -i $f.FullName -c:v libx264 -crf 20 -preset medium -pix_fmt yuv420p -c:a aac -b:a 192k $outFile
    if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $outFile)) {
        Write-Host "[完成] $($f.Name)  ->  $outDir\" -ForegroundColor Green; $done++
    } else {
        Write-Host "[失敗] $($f.Name)" -ForegroundColor Red; $fail++
    }
}

Write-Host ''
Write-Host '============================================================'
Write-Host " 全部處理完畢：成功 $done 支，跳過 $skip 支，失敗 $fail 支"
Write-Host ' 轉好的檔在各來源資料夾的「轉好H264」裡'
Write-Host '============================================================'
Add-Type -AssemblyName System.Windows.Forms | Out-Null
[System.Windows.Forms.MessageBox]::Show(
    "轉檔完成`n`n成功 $done 支，跳過 $skip 支，失敗 $fail 支`n`n轉好的檔案放在原本影片旁邊的`n「轉好H264」資料夾裡。",
    '轉檔完成', 0, 64) | Out-Null
