﻿# =============================================================
#  影片下載＋逐字稿工具包　安裝程式（v2）
#  由 setup.bat 啟動。全部東西都裝在這個資料夾裡的 runtime\，
#  不會動到你電腦原本的 Python、不用管理員權限。
# =============================================================
# 註：這裡刻意用 Continue 不用 Stop。PowerShell 5.1 只要原生程式（python.exe / curl.exe）
# 往 stderr 吐一行字，在 Stop 模式下就會被當成致命錯誤整支中斷——真正該看的是離開代碼。
$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$kit = $PSScriptRoot
$rt  = Join-Path $kit 'runtime'
$py  = Join-Path $rt  'python.exe'
$log = Join-Path $kit 'setup-log.txt'

$PY_URL     = 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip'
$PIP_URL    = 'https://bootstrap.pypa.io/get-pip.py'
# GitHub 擺第一個：gyan.dev 從台灣連常常只有幾十 KB/s，100MB 要下半小時以上
$FFMPEG_URL = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip'
$FFMPEG_ALT = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'

# ---------- 小工具 ----------
function Log([string]$m) {
    $line = '{0}  {1}' -f (Get-Date -Format 'HH:mm:ss'), $m
    Write-Host $m
    Add-Content -LiteralPath $log -Value $line -Encoding UTF8
}
function LogOnly([string]$m) {
    Add-Content -LiteralPath $log -Value $m -Encoding UTF8
}
function Box([string]$text, [string]$title, [int]$icon) {
    # KIT_SILENT=1 給自動化測試用，平常使用者不會有這個變數
    if ($env:KIT_SILENT -eq '1') { Write-Host "[$title] $text"; return }
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    [System.Windows.Forms.MessageBox]::Show($text, $title, 0, $icon) | Out-Null
}
function Die([string]$reason) {
    Log ''
    Log "[安裝失敗] $reason"
    LogOnly '--- 失敗結束 ---'
    Box "安裝沒有完成。`n`n原因：$reason`n`n這個資料夾裡有一個檔案叫`n【setup-log.txt】`n把它整個傳給介紹你來的朋友，`n一看就知道卡在哪裡，不用你猜。`n`n（多數情況只要重點一次 setup.bat 就會過，`n　它會從斷掉的地方接著裝。）" '安裝失敗' 16
    exit 1
}
# 跑一次專用 python，回傳 @{code=離開代碼; out=全部輸出}
function Py {
    param([Parameter(ValueFromRemainingArguments = $true)]$a)
    $global:LASTEXITCODE = 0
    $out = & $py @a 2>&1 | Out-String
    return @{ code = $LASTEXITCODE; out = $out }
}
function HasModule([string]$m) { (Py -c "import $m").code -eq 0 }

# 邊下載邊回報進度。沒有進度的話，慢速網路上使用者會以為當機然後關掉視窗——
# 那是這個工具包最早期最大的失敗原因，不是真的裝不起來。
function Grab([string]$url, [string]$dest, [string]$what) {
    Log "  下載 $what ..."
    $done = $false
    try {
        $req = [Net.HttpWebRequest]::Create($url)
        $req.UserAgent = 'Mozilla/5.0'
        $req.Timeout = 40000
        $req.ReadWriteTimeout = 120000
        $res = $req.GetResponse()
        $total = $res.ContentLength
        $in = $res.GetResponseStream()
        $out = [IO.File]::Create($dest)
        $buf = New-Object byte[] 262144
        $sum = 0; $t0 = Get-Date; $next = 6
        while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
            $out.Write($buf, 0, $n)
            $sum += $n
            $sec = ((Get-Date) - $t0).TotalSeconds
            if ($sec -ge $next) {
                $next = $sec + 6
                $mb = [math]::Round($sum / 1MB, 1)
                $kbs = [math]::Round($sum / 1KB / $sec)
                if ($total -gt 0) {
                    $pct = [math]::Round($sum * 100 / $total)
                    $eta = [math]::Round((($total - $sum) / ($sum / $sec)) / 60, 1)
                    Write-Host "      $mb MB / $([math]::Round($total/1MB)) MB（$pct%）　$kbs KB/秒　大約還要 $eta 分鐘"
                } else {
                    Write-Host "      已下載 $mb MB（$kbs KB/秒）"
                }
            }
        }
        $out.Close(); $in.Close(); $res.Close()
        $done = $true
    } catch {
        LogOnly "直接下載失敗：$($_.Exception.Message)"
        try { if ($out) { $out.Close() } } catch {}
        Log '  換一種方式重試…'
        & curl.exe -L --retry 2 --connect-timeout 30 -o $dest $url 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) { $done = $true }
    }
    if (-not $done) { return $false }
    if (-not (Test-Path -LiteralPath $dest)) { return $false }
    $mb = [math]::Round((Get-Item -LiteralPath $dest).Length / 1MB, 1)
    if ($mb -lt 0.2) { LogOnly "檔案太小（$mb MB），視為下載失敗"; return $false }
    Log "  完成（$mb MB）"
    return $true
}

# ---------- 開場 ----------
Set-Content -LiteralPath $log -Value "==== 安裝紀錄 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ====" -Encoding UTF8
LogOnly "資料夾：$kit"
LogOnly "Windows：$([Environment]::OSVersion.VersionString) / $env:PROCESSOR_ARCHITECTURE"
LogOnly "PowerShell：$($PSVersionTable.PSVersion)"

# ---------- 0. 防呆：有沒有先解壓縮 ----------
if ($kit -like '*\AppData\Local\Temp\*' -or $kit -like '*\Temp\*Rar$*' -or $kit -like '*\Temp\7z*') {
    Box "你現在是【直接在壓縮檔裡面】點開它的，這樣裝不起來。`n`n請照這樣做：`n1. 關掉這個視窗`n2. 找到剛下載的 downloader-kit.zip`n3. 對它按【右鍵】→【全部解壓縮】`n4. 解壓縮位置選【桌面】`n5. 打開解出來的資料夾，再點 setup.bat" '請先解壓縮' 48
    exit 1
}
if ($kit -notmatch '^[A-Za-z]:\\') {
    Box "這個資料夾放的位置不支援（看起來在網路磁碟或 USB 上）。`n`n請把整個資料夾複製到【桌面】再點一次 setup.bat。" '請換個位置' 48
    exit 1
}

Write-Host ''
Write-Host '  ============================================'
Write-Host '    影片下載＋逐字稿工具包　安裝中'
Write-Host '  ============================================'
Write-Host '  第一次安裝大約 5～15 分鐘（看網速），'
Write-Host '  跑完會跳一個對話框告訴你結果。'
Write-Host '  這中間可以去忙別的，不要關掉這個視窗。'
Write-Host ''

# ---------- 0.5 解除 Windows 對下載檔案的封鎖 ----------
try {
    Get-ChildItem -LiteralPath $kit -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    Log '[0/5] 已解除 Windows 對下載檔案的封鎖'
} catch { LogOnly "Unblock-File 略過：$($_.Exception.Message)" }

# ---------- 1. 專用 Python ----------
if (Test-Path -LiteralPath $py) {
    Log '[1/5] 專用 Python 已經在了，跳過'
} else {
    Log '[1/5] 安裝專用 Python（只裝在這個資料夾，不影響你電腦原本的設定）'
    $tmpZip = Join-Path $env:TEMP 'kit-python.zip'
    if (Test-Path -LiteralPath $tmpZip) { Remove-Item -LiteralPath $tmpZip -Force }
    if (-not (Grab $PY_URL $tmpZip 'Python（約 11 MB）')) { Die '下載 Python 失敗，請確認網路連線後重跑 setup.bat' }
    if (-not (Test-Path -LiteralPath $rt)) { New-Item -ItemType Directory -Path $rt | Out-Null }
    try { Expand-Archive -LiteralPath $tmpZip -DestinationPath $rt -Force -ErrorAction Stop }
    catch { LogOnly $_.Exception.Message; Die '解壓縮 Python 失敗，請重跑 setup.bat' }
    Remove-Item -LiteralPath $tmpZip -Force -ErrorAction SilentlyContinue
    if (-not (Test-Path -LiteralPath $py)) { Die 'Python 解壓縮後找不到 python.exe，請重跑 setup.bat' }

    # 讓這份內嵌 Python 認得 site-packages（不改這行的話裝了套件也 import 不到）
    $pth = Get-ChildItem -LiteralPath $rt -Filter 'python*._pth' | Select-Object -First 1
    if ($pth) {
        $body = Get-Content -LiteralPath $pth.FullName
        $body = $body -replace '^\s*#\s*import\s+site\s*$', 'import site'
        if ($body -notcontains 'import site') { $body += 'import site' }
        if ($body -notcontains 'Lib\site-packages') { $body += 'Lib\site-packages' }
        Set-Content -LiteralPath $pth.FullName -Value $body -Encoding ASCII
        LogOnly "已修正 $($pth.Name)"
    }
    Log '  Python OK'
}
LogOnly (Py -c "import sys;print('python',sys.version)").out

# ---------- 2. pip ----------
if ((Py -m pip --version).code -eq 0) {
    Log '[2/5] pip 已經在了，跳過'
} else {
    Log '[2/5] 安裝套件管理員 pip'
    $getpip = Join-Path $env:TEMP 'get-pip.py'
    if (-not (Grab $PIP_URL $getpip 'get-pip（約 2 MB）')) { Die '下載 pip 失敗，請確認網路連線後重跑 setup.bat' }
    LogOnly (Py $getpip --no-warn-script-location).out
    Remove-Item -LiteralPath $getpip -Force -ErrorAction SilentlyContinue
    if ((Py -m pip --version).code -ne 0) { Die 'pip 安裝失敗，請重跑 setup.bat' }
    Log '  pip OK'
}

# ---------- 3. 套件 ----------
$need = @(@('yt_dlp', 'faster_whisper', 'opencc', 'truststore') | Where-Object { -not (HasModule $_) })
if ($need.Count -eq 0) {
    Log '[3/5] 下載／轉錄引擎已經在了，跳過'
} else {
    Log '[3/5] 安裝下載＋轉錄引擎（這步最久，約 3～10 分鐘，請耐心等）'
    $pkgs = 'yt-dlp', 'faster-whisper', 'opencc-python-reimplemented', 'truststore'
    & $py -m pip install --no-warn-script-location --disable-pip-version-check -U @pkgs 2>&1 |
        ForEach-Object { LogOnly "$_"; if ("$_" -match '^(Collecting|Installing|Successfully|ERROR)') { Write-Host "    $_" } }
    $bad = @(@('yt_dlp', 'faster_whisper', 'opencc', 'truststore') | Where-Object { -not (HasModule $_) })
    if ($bad.Count -gt 0) { Die ('這些引擎沒裝成功：' + ($bad -join '、') + '（多半是網路中斷，重跑 setup.bat 通常就好）') }
    Log '  引擎 OK'
}

# ---------- 4. ffmpeg ----------
$ff = Join-Path $rt 'ffmpeg.exe'
if (Test-Path -LiteralPath $ff) {
    Log '[4/5] ffmpeg 已經在了，跳過'
} else {
    Log '[4/5] 安裝影音處理程式 ffmpeg（約 160 MB，下面會顯示進度）'
    $ffZip = Join-Path $env:TEMP 'kit-ffmpeg.zip'
    $ffDir = Join-Path $env:TEMP 'kit-ffmpeg-x'
    if (Test-Path -LiteralPath $ffZip) { Remove-Item -LiteralPath $ffZip -Force }
    $ok = Grab $FFMPEG_URL $ffZip 'ffmpeg'
    if (-not $ok) { Log '  主要來源失敗，改用備用來源…'; $ok = Grab $FFMPEG_ALT $ffZip 'ffmpeg（備用來源）' }
    if (-not $ok) { Die '下載 ffmpeg 失敗，請確認網路連線（或關掉 VPN）後重跑 setup.bat' }
    if (Test-Path -LiteralPath $ffDir) { Remove-Item -LiteralPath $ffDir -Recurse -Force -ErrorAction SilentlyContinue }
    try { Expand-Archive -LiteralPath $ffZip -DestinationPath $ffDir -Force -ErrorAction Stop }
    catch { LogOnly $_.Exception.Message; Die '解壓縮 ffmpeg 失敗，請重跑 setup.bat' }
    foreach ($exe in @('ffmpeg.exe', 'ffprobe.exe')) {
        $src = Get-ChildItem -LiteralPath $ffDir -Recurse -Filter $exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($src) { Copy-Item -LiteralPath $src.FullName -Destination (Join-Path $rt $exe) -Force }
    }
    Remove-Item -LiteralPath $ffZip -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $ffDir -Recurse -Force -ErrorAction SilentlyContinue
    if (-not (Test-Path -LiteralPath $ff)) { Die 'ffmpeg 解壓縮後找不到執行檔，請重跑 setup.bat' }
    Log '  ffmpeg OK'
}

# ---------- 5. 語音模型（先抓起來放，失敗不影響安裝） ----------
$modelOK = $true
Log '[5/5] 先下載語音辨識模型（約 500 MB，只有這一次）'
$dl = @'
import sys
try:
    from faster_whisper import WhisperModel
    WhisperModel("small", device="cpu", compute_type="int8")
    print("MODEL_OK")
except Exception as e:
    print("MODEL_FAIL:" + str(e)[:300])
'@
$mtmp = Join-Path $env:TEMP 'kit-model.py'
Set-Content -LiteralPath $mtmp -Value $dl -Encoding UTF8
$mOut = Join-Path $env:TEMP 'kit-model.out'
$mErr = Join-Path $env:TEMP 'kit-model.err'
$hub  = Join-Path $env:USERPROFILE '.cache\huggingface\hub'
function HubMB {
    if (-not (Test-Path -LiteralPath $hub)) { return 0 }
    $s = (Get-ChildItem -LiteralPath $hub -Recurse -File -ErrorAction SilentlyContinue |
          Measure-Object -Property Length -Sum).Sum
    if ($s) { return [math]::Round($s / 1MB) } else { return 0 }
}
$base = HubMB   # 電腦裡可能本來就有別的模型，只算這次「多出來」的
$proc = Start-Process -FilePath $py -ArgumentList "`"$mtmp`"" -NoNewWindow -PassThru `
        -RedirectStandardOutput $mOut -RedirectStandardError $mErr
$t0 = Get-Date
while (-not $proc.HasExited) {
    Start-Sleep -Seconds 6
    $got = [math]::Max(0, (HubMB) - $base)
    Write-Host ("      已下載約 {0} MB / 約 480 MB　（已經 {1} 分鐘）" -f $got, [math]::Round(((Get-Date) - $t0).TotalMinutes, 1))
}
$out = ((Get-Content -LiteralPath $mOut -Raw -ErrorAction SilentlyContinue) + "`n" +
        (Get-Content -LiteralPath $mErr -Raw -ErrorAction SilentlyContinue))
LogOnly $out
Remove-Item -LiteralPath $mtmp, $mOut, $mErr -Force -ErrorAction SilentlyContinue
if ($out -match 'MODEL_OK') { Log '  語音模型 OK' }
else { $modelOK = $false; Log '  語音模型這次沒抓成功（不影響安裝，第一次轉逐字稿時會自動再抓一次）' }

# ---------- 收工 ----------
LogOnly '--- 安裝成功 ---'
Write-Host ''
Write-Host '  ============================================'
Write-Host '    安裝完成'
Write-Host '  ============================================'
Write-Host ''

$extra = if ($modelOK) { '' } else { "`n`n（語音模型這次沒抓下來，不影響使用，第一次轉逐字稿時會自動再抓，那一次會慢一點。）" }
Box "安裝完成，可以用了！`n`n接下來只要做一件事：`n【點兩下 start.bat】`n`n瀏覽器會自動跳出一個綠色的下載器網頁，`n把影片網址貼進去按下載就好。`n`n影片會存到桌面的「影片下載」資料夾，`n旁邊會附一份打好的繁體逐字稿。`n`n這個 setup.bat 以後都不用再點了。$extra" '安裝完成' 64
exit 0
