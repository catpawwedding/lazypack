﻿# 啟動影片下載器（由 start.bat 呼叫）
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$env:PYTHONIOENCODING = 'utf-8'
$kit = $PSScriptRoot
$rt  = Join-Path $kit 'runtime'
$py  = Join-Path $rt  'python.exe'

if (-not (Test-Path -LiteralPath $py)) {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    [System.Windows.Forms.MessageBox]::Show(
        "還沒安裝完成喔。`n`n請先點兩下同一個資料夾裡的`n【setup.bat】`n等它跳出「安裝完成」的視窗，`n再回來點 start.bat。",
        '請先安裝', 0, 48) | Out-Null
    exit 1
}

$env:Path = "$rt;$kit;" + $env:Path
& $py -u (Join-Path $kit 'downloader.py')
Write-Host ''
Read-Host '按 Enter 關閉這個視窗'
