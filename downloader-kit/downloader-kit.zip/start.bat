@echo off
chcp 65001 >nul
title Video Downloader
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\_start.ps1"
