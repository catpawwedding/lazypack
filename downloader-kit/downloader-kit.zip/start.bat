@echo off
chcp 65001 >nul
title Video Downloader
cd /d "%~dp0"
set PATH=%~dp0;%PATH%
python -c "import sys" >nul 2>nul
if errorlevel 1 (
  echo Python not working yet. Please run setup.bat first.
  echo (If a Microsoft Store window just opened, that is Windows'
  echo  FAKE python shortcut - close it and run setup.bat.)
  pause
  exit /b
)
echo Updating download engine, please wait...
python -m pip install -U yt-dlp -q
echo Starting downloader...
python -u downloader.py
pause
