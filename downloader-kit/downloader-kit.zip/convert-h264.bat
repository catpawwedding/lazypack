@echo off
chcp 65001 >nul
title Convert to H264
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\_convert-h264.ps1" %*
