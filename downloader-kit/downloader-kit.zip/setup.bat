@echo off
REM ASCII only on purpose - Chinese messages live in _setup.ps1 (cp950 trap)
chcp 65001 >nul
title Setup - video downloader kit
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\_setup.ps1"
if errorlevel 1 (
  echo.
  echo Setup did not finish. Send "setup-log.txt" in this folder to your friend.
  echo.
  pause
)
