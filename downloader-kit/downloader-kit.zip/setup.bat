@echo off
REM ============================================================
REM  Toolkit setup - run ONCE on a new PC
REM  ASCII only on purpose (PS5.1 / cp950 encoding trap)
REM ============================================================
title Toolkit Setup
cd /d "%~dp0"
echo.
echo ==========================================
echo   Toolkit Setup  (run once)
echo ==========================================
echo.

REM ---------- 1. Python (REAL check - the Store fake python passes "where") ----------
python -c "import sys" >nul 2>nul
if not errorlevel 1 goto pyok
echo [1/4] Python NOT found (or only Windows' fake Store shortcut).
where winget >nul 2>nul
if errorlevel 1 goto pydirect
echo       Installing Python via winget...
winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
goto pyagain
:pydirect
echo       Downloading Python installer from python.org (about 25 MB)...
curl -L -o "%TEMP%\py312-setup.exe" https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe
if errorlevel 1 (
    echo [ERROR] Download failed. Check your internet connection.
    pause
    exit /b
)
echo       Installing Python quietly (takes a minute)...
"%TEMP%\py312-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1
:pyagain
echo.
echo   Python installed. Now CLOSE this window and
echo   double-click setup.bat AGAIN to finish setup.
pause
exit /b
:pyok
echo [1/4] Python OK
python --version

REM ---------- 2. Python packages ----------
echo.
echo [2/4] Installing python packages (can take a few minutes)...
python -m pip install --upgrade pip
python -m pip install faster-whisper opencc-python-reimplemented truststore yt-dlp
if errorlevel 1 (
    echo [ERROR] pip install failed. Check your internet connection.
    pause
    exit /b
)
echo       packages OK

REM ---------- 3. ffmpeg (downloaded INTO this folder - no PATH problems) ----------
echo.
if exist "%~dp0ffmpeg.exe" goto ffok
ffmpeg -version >nul 2>nul
if not errorlevel 1 goto ffok
echo [3/4] ffmpeg NOT found. Downloading (about 100 MB, please wait)...
curl -L -o "%TEMP%\ffmpeg-tk.zip" https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip
if errorlevel 1 (
    echo [ERROR] ffmpeg download failed. Check your internet connection.
    pause
    exit /b
)
rmdir /s /q "%TEMP%\ffx-tk" 2>nul
mkdir "%TEMP%\ffx-tk"
tar -xf "%TEMP%\ffmpeg-tk.zip" -C "%TEMP%\ffx-tk"
for /d %%D in ("%TEMP%\ffx-tk\ffmpeg-*") do (
    copy /y "%%D\bin\ffmpeg.exe" "%~dp0" >nul
    copy /y "%%D\bin\ffprobe.exe" "%~dp0" >nul
)
if not exist "%~dp0ffmpeg.exe" (
    echo [ERROR] ffmpeg extract failed.
    pause
    exit /b
)
:ffok
echo [3/4] ffmpeg OK

REM ---------- 4. final check ----------
echo.
echo [4/4] Final check...
python -c "import faster_whisper, yt_dlp, opencc, truststore; print('      all packages OK')"
if errorlevel 1 (
    echo [ERROR] Something is still missing. Run check.bat and
    echo         send a screenshot of its window.
    pause
    exit /b
)

echo.
echo ==========================================
echo   Setup done!
echo   - Double-click start.bat  =  video downloader web page
echo   - Drag a video/audio file onto transcribe.bat  =  transcript
echo ==========================================
echo.
echo NOTE: the FIRST transcription downloads a 500MB model
echo       (that one run is slow, later runs are fast).
echo.
pause
