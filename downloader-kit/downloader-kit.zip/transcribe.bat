@echo off
chcp 65001 >nul
title Make transcript
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File ".\_transcribe.ps1" %*
