﻿# 拖曳影片／音檔／資料夾進來 → 產出繁體逐字稿（由 transcribe.bat 呼叫）
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$env:PYTHONIOENCODING = 'utf-8'
$kit = $PSScriptRoot
$rt  = Join-Path $kit 'runtime'
$py  = Join-Path $rt  'python.exe'

if (-not (Test-Path -LiteralPath $py)) {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    [System.Windows.Forms.MessageBox]::Show(
        "還沒安裝完成喔。`n`n請先點兩下同一個資料夾裡的`n【setup.bat】，`n等它跳出「安裝完成」再回來用。",
        '請先安裝', 0, 48) | Out-Null
    exit 1
}

$env:Path = "$rt;$kit;" + $env:Path

if ($args.Count -eq 0) {
    Write-Host ''
    Write-Host '  用法：把影片檔、錄音檔、或整個資料夾'
    Write-Host '        「拖」到 transcribe.bat 上面放開，就會產逐字稿。'
    Write-Host ''
    Read-Host '按 Enter 關閉'
    exit
}

& $py (Join-Path $kit 'transcribe.py') @args
Write-Host ''
Read-Host '按 Enter 關閉這個視窗'
