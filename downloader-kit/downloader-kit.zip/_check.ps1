﻿# 一鍵體檢：產出「診斷報告.txt」，卡關時把這個檔傳給朋友就好
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$kit = $PSScriptRoot
$rt  = Join-Path $kit 'runtime'
$py  = Join-Path $rt  'python.exe'
$rep = Join-Path $kit '診斷報告.txt'
$L = New-Object System.Collections.Generic.List[string]

function Add2($s) { $L.Add($s); Write-Host $s }

Add2 "==== 工具包診斷報告 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===="
Add2 "資料夾：$kit"
Add2 "Windows：$([Environment]::OSVersion.VersionString) / $env:PROCESSOR_ARCHITECTURE"
Add2 "PowerShell：$($PSVersionTable.PSVersion)"
Add2 ''

Add2 '--- 1. 專用 Python ---'
if (Test-Path -LiteralPath $py) {
    Add2 ('  OK  ' + ((& $py -c "import sys;print(sys.version.split()[0])" 2>&1) -join ' '))
} else {
    Add2 '  沒有！請點兩下 setup.bat 安裝'
}

Add2 ''
Add2 '--- 2. 下載／轉錄引擎 ---'
if (Test-Path -LiteralPath $py) {
    foreach ($m in @('yt_dlp', 'faster_whisper', 'opencc', 'truststore')) {
        & $py -c "import $m" *> $null
        if ($LASTEXITCODE -eq 0) { Add2 "  OK      $m" } else { Add2 "  缺少！   $m" }
    }
} else { Add2 '  （沒有 Python，無法檢查）' }

Add2 ''
Add2 '--- 3. ffmpeg ---'
if (Test-Path -LiteralPath (Join-Path $rt 'ffmpeg.exe')) { Add2 '  OK' } else { Add2 '  沒有！請點兩下 setup.bat 安裝' }

Add2 ''
Add2 '--- 4. 語音模型 ---'
$hf = Join-Path $env:USERPROFILE '.cache\huggingface\hub'
if (Test-Path -LiteralPath $hf) {
    $m = Get-ChildItem -LiteralPath $hf -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '*whisper*small*' }
    if ($m) { Add2 '  OK  （已下載，第一次轉稿不用等）' } else { Add2 '  還沒下載（第一次轉逐字稿時會自動抓，約 500MB）' }
} else { Add2 '  還沒下載（第一次轉逐字稿時會自動抓，約 500MB）' }

Add2 ''
Add2 '--- 5. 下載器有沒有已經開著 ---'
$n = (netstat -ano | Select-String ':8765' | Select-String 'LISTENING')
if ($n) { Add2 ('  有一個下載器正在跑：' + ($n -join ' ')) } else { Add2 '  沒有（正常）' }

Add2 ''
Add2 '--- 6. 網路連線 ---'
foreach ($h in @('www.python.org', 'pypi.org', 'www.youtube.com')) {
    $ok = Test-NetConnection -ComputerName $h -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
    Add2 ("  {0,-18} {1}" -f $h, $(if ($ok) { '通' } else { '不通（可能被防火牆或 VPN 擋住）' }))
}

Add2 ''
$slog = Join-Path $kit 'setup-log.txt'
if (Test-Path -LiteralPath $slog) {
    Add2 '--- 7. 上次安裝紀錄（最後 40 行）---'
    Get-Content -LiteralPath $slog -Tail 40 | ForEach-Object { $L.Add('  ' + $_) }
} else {
    Add2 '--- 7. 上次安裝紀錄 --- 找不到 setup-log.txt（可能還沒跑過 setup.bat）'
}

Set-Content -LiteralPath $rep -Value $L -Encoding UTF8
Write-Host ''
Write-Host "報告已存成：$rep"

Add-Type -AssemblyName System.Windows.Forms | Out-Null
[System.Windows.Forms.MessageBox]::Show(
    "體檢完成。`n`n這個資料夾裡多了一個檔案：`n【診斷報告.txt】`n`n把它傳給介紹你來的朋友，`n他一看就知道卡在哪，不用你形容。`n`n（按確定會幫你打開這個檔）",
    '體檢完成', 0, 64) | Out-Null
Start-Process notepad.exe $rep
