# ============================================================
#  Transcriber launcher - started by transcribe.bat (drag & drop)
#  Chinese messages live in transcribe.py; this file stays ASCII
#  so it never hits the PS5.1 UTF-8 BOM encoding trap.
# ============================================================
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = 'utf-8'

# use the ffmpeg.exe that setup.bat drops into this folder (no PATH setup needed)
$env:Path = "$PSScriptRoot;" + $env:Path

$py = (Get-Command python -ErrorAction SilentlyContinue)
if ($py) { python -c "import sys" | Out-Null }
if ((-not $py) -or ($LASTEXITCODE -ne 0)) {
    Write-Host "[ERROR] python not working. Please run setup.bat first." -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit
}

python "$PSScriptRoot\transcribe.py" @args

Read-Host "Press Enter to close"
