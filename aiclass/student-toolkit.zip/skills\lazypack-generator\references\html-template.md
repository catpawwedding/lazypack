# HTML 懶人包模板規範（學員版）

本檔案規範產出的 HTML 結構、必要區塊、與品牌資產填法。
所有 `{大寫佔位符}` 都從 SKILL.md 的「品牌設定區」與文案內容填入。

## 整體結構（由上到下）

```
1. <head>（meta + 內嵌 CSS）
2. 頁首品牌區（Logo 或純文字品牌名）
3. 主標題區：懶人包名稱（大標，含 highlight 螢光筆效果）＋一句副標
4. Hero 插圖（內嵌 SVG，主題具象元素）
5. 引言（1-2 句）
6. 重點卡片（3-5 張）：大數字編號＋短橫線＋章節圖示＋標題＋內文
7. 結論金句（深色卡片＋金色強調字）
8. CTA 區（依設定：社群卡／認識我卡，留空就省略）
9. 頁尾品牌區（品牌字＋日期）
10. 右下角浮動按鈕（LINE 綠＋電話・品牌色）
```

## 佔位符對照

| 佔位符 | 來源 |
|--------|------|
| `{BRAND_COLOR}` | 品牌設定：品牌主色（預設 `#D9342B`） |
| `{BRAND_NAME_PLAIN}` | 品牌名中「不強調」的部分（例：中壢專業房仲） |
| `{BRAND_NAME_ACCENT}` | 品牌名中要標品牌色的部分（例：喵爸） |
| `{LOGO_IMG}` | Logo 有填 → `<img src="..." class="brand-logo">`；留空 → 整行省略 |
| `{LAZYPACK_NAME_PLAIN}` / `{LAZYPACK_NAME_HIGHLIGHT}` | 懶人包名稱前半／要螢光筆標亮的後半 |
| `{SUBTITLE}` | 一句副標（句號結尾） |
| `{HERO_SVG}` | 內嵌 SVG 主題插圖 |
| `{INTRO}` | 引言（每句句號結尾） |
| `{POINTS}` | 重點卡片群 |
| `{CONCLUSION_HTML}` | 結論金句（可含 `<span class="accent">`） |
| `{COMMUNITY_TITLE}` / `{COMMUNITY_DESC}` / `{COMMUNITY_URL}` | 社群 CTA（設定沒填 → 整卡省略） |
| `{CARD_TITLE}` / `{CARD_URL}` | 名片／官網 CTA（設定沒填 → 整卡省略） |
| `{LINE_URL}` / `{PHONE}` | 浮動按鈕（必填） |
| `{DATE}` | 產出日期（YYYY.MM.DD） |

## 完整 HTML 骨架

```html
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{LAZYPACK_NAME_PLAIN}{LAZYPACK_NAME_HIGHLIGHT} · {BRAND_NAME_PLAIN} {BRAND_NAME_ACCENT}</title>
<style>
  :root { --brand: {BRAND_COLOR}; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html { -webkit-text-size-adjust: 100%; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "PingFang TC",
                 "Microsoft JhengHei", "Helvetica Neue", sans-serif;
    background: #FAF8F4;
    color: #2C2A26;
    line-height: 1.75;
    -webkit-font-smoothing: antialiased;
    font-size: 16px;
  }
  .container { max-width: 640px; margin: 0 auto; padding: 24px 20px 120px; }

  /* === 頁首品牌區 === */
  .brand-header { text-align: center; padding: 16px 0 28px; border-bottom: 2px solid #F3E3E0; margin-bottom: 32px; }
  .brand-header .brand-logo { width: 72px; height: 72px; display: block; margin: 0 auto 10px; }
  .brand-header .brand-name { font-size: 15px; color: #2C2A26; font-weight: 700; letter-spacing: 1px; }
  .brand-header .brand-name .accent { color: var(--brand); }

  /* === 主標題區 === */
  .header { text-align: center; margin-bottom: 28px; }
  .header h1 { font-size: 32px; font-weight: 800; color: #2C2A26; line-height: 1.3; margin-bottom: 14px; }
  .header h1 .highlight { background: linear-gradient(180deg, transparent 60%, #FFE5A0 60%); padding: 0 4px; }
  .subtitle { font-size: 17px; color: #6B6660; line-height: 1.6; }

  /* === Hero 插圖 === */
  .hero { background: linear-gradient(160deg, #FFF7EC, #FCEDE6); border-radius: 16px; padding: 20px; margin-bottom: 32px; text-align: center; }
  .hero svg { width: 100%; max-width: 320px; height: auto; }

  /* === 引言 === */
  .intro { background: #FFF; border-left: 5px solid var(--brand); padding: 20px 22px; margin-bottom: 36px;
           border-radius: 6px; font-size: 16px; color: #4A463F; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }

  /* === 重點卡片 === */
  .points { display: flex; flex-direction: column; gap: 18px; margin-bottom: 36px; }
  .point-card { background: #FFF; border-radius: 14px; padding: 28px 24px 26px; box-shadow: 0 2px 12px rgba(0,0,0,0.05); position: relative; }
  /* 大數字編號（不用圓圈！圓圈在手機上字會跑位） */
  .point-number { font-size: 36px; font-weight: 900; color: var(--brand); line-height: 1; letter-spacing: -1px;
                  margin-bottom: 8px; font-family: "Helvetica Neue", "Arial", sans-serif; }
  .point-number-bar { display: block; width: 36px; height: 3px; background: var(--brand); margin-bottom: 16px; border-radius: 2px; }
  .point-icon { position: absolute; top: 24px; right: 22px; width: 44px; height: 44px; background: #FFF1EE;
                border-radius: 12px; display: flex; align-items: center; justify-content: center; }
  .point-icon svg { width: 24px; height: 24px; stroke: var(--brand); fill: none; stroke-width: 2; }
  .point-title { font-size: 20px; font-weight: 700; color: #2C2A26; margin-bottom: 12px; line-height: 1.4; }
  .point-body { font-size: 16px; color: #4A463F; line-height: 1.75; }
  .point-body strong { color: var(--brand); font-weight: 700; }
  .point-body ul { margin: 12px 0 0 20px; }
  .point-body li { margin-bottom: 8px; }
  .point-example { margin-top: 14px; padding: 14px 16px; background: #FFF5E0; border-radius: 10px;
                   font-size: 15px; color: #6B5230; border-left: 3px solid #F5B946; }
  .point-example::before { content: "💡 "; }

  /* === 結論 === */
  .conclusion { background: linear-gradient(135deg, #2C2A26 0%, #3D3833 100%); color: #FAF8F4; padding: 28px 24px;
                border-radius: 14px; text-align: center; font-size: 19px; font-weight: 600; line-height: 1.6;
                margin-bottom: 40px; box-shadow: 0 4px 16px rgba(0,0,0,0.1); }
  .conclusion .accent { color: #FFD06A; }

  /* === CTA 區 === */
  .cta-section { margin-bottom: 36px; }
  .community-cta { background: linear-gradient(135deg, var(--brand) 0%, #B89968 100%); color: #FFF; padding: 32px 24px;
                   border-radius: 18px; text-align: center; margin-bottom: 16px; box-shadow: 0 6px 20px rgba(0,0,0,0.18); }
  .community-cta h3 { font-size: 22px; font-weight: 800; margin-bottom: 14px; }
  .community-cta p { font-size: 15px; line-height: 1.7; margin-bottom: 20px; opacity: 0.95; }
  .community-cta .cta-button { display: inline-block; background: #FFF; color: #2C2A26; padding: 14px 32px;
                               border-radius: 999px; text-decoration: none; font-weight: 700; font-size: 16px;
                               box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
  .card-cta { background: #FFF; border: 2px solid #2C2A26; color: #2C2A26; padding: 26px 24px; border-radius: 18px; text-align: center; }
  .card-cta h3 { font-size: 20px; font-weight: 700; margin-bottom: 16px; }
  .card-cta .cta-button { display: inline-block; background: #2C2A26; color: #FFF; padding: 13px 30px;
                          border-radius: 999px; text-decoration: none; font-weight: 700; font-size: 15px; }

  /* === 頁尾品牌區 === */
  .brand-footer { text-align: center; padding-top: 32px; border-top: 2px solid #F3E3E0; }
  .brand-footer .footer-name { font-size: 13px; color: #6B6660; letter-spacing: 1px; margin-bottom: 4px; }
  .brand-footer .footer-name .accent { color: var(--brand); font-weight: 700; }
  .brand-footer .footer-date { font-size: 12px; color: #A89F92; }

  /* === 浮動按鈕 === */
  .floating-actions { position: fixed; right: 16px; bottom: 20px; display: flex; flex-direction: column; gap: 12px; z-index: 999; }
  .floating-actions a { width: 58px; height: 58px; border-radius: 50%; display: flex; align-items: center;
                        justify-content: center; box-shadow: 0 6px 20px rgba(0,0,0,0.25); text-decoration: none; transition: transform 0.2s; }
  .floating-actions a:active { transform: scale(0.92); }
  .floating-actions .fab-line { background: #06C755; }
  .floating-actions .fab-phone { background: var(--brand); }
  .floating-actions a svg { width: 28px; height: 28px; fill: #FFF; }

  /* === 桌機微調 === */
  @media (min-width: 768px) {
    body { font-size: 17px; }
    .container { padding: 32px 24px 56px; }
    .header h1 { font-size: 38px; }
    .point-title { font-size: 22px; }
    .point-body { font-size: 17px; }
    .point-number { font-size: 42px; }
    .floating-actions { right: 24px; bottom: 24px; }
    .floating-actions a { width: 64px; height: 64px; }
    .floating-actions a svg { width: 32px; height: 32px; }
  }
</style>
</head>
<body>
  <div class="container">

    <!-- 頁首品牌區（必含；沒 Logo 就只留文字） -->
    <div class="brand-header">
      {LOGO_IMG}
      <div class="brand-name">{BRAND_NAME_PLAIN} <span class="accent">{BRAND_NAME_ACCENT}</span></div>
    </div>

    <!-- 主標題 -->
    <div class="header">
      <h1>{LAZYPACK_NAME_PLAIN}<span class="highlight">{LAZYPACK_NAME_HIGHLIGHT}</span></h1>
      <p class="subtitle">{SUBTITLE}</p>
    </div>

    <!-- Hero 插圖（內嵌 SVG） -->
    <div class="hero">
      {HERO_SVG}
    </div>

    <!-- 引言 -->
    <div class="intro">
      {INTRO}
    </div>

    <!-- 重點卡片 -->
    <div class="points">
      {POINTS}
    </div>

    <!-- 結論 -->
    <div class="conclusion">
      {CONCLUSION_HTML}
    </div>

    <!-- CTA 區（依品牌設定，沒填的卡整個省略） -->
    <div class="cta-section">

      <div class="community-cta">
        <h3>{COMMUNITY_TITLE}</h3>
        <p>{COMMUNITY_DESC}</p>
        <a href="{COMMUNITY_URL}" class="cta-button" target="_blank" rel="noopener">立即加入 →</a>
      </div>

      <div class="card-cta">
        <h3>{CARD_TITLE}</h3>
        <a href="{CARD_URL}" class="cta-button" target="_blank" rel="noopener">認識我 →</a>
      </div>

    </div>

    <!-- 頁尾品牌區（必含） -->
    <div class="brand-footer">
      <div class="footer-name">{BRAND_NAME_PLAIN} <span class="accent">{BRAND_NAME_ACCENT}</span></div>
      <div class="footer-date">{DATE}</div>
    </div>

  </div>

  <!-- 浮動按鈕（必含） -->
  <div class="floating-actions">
    <a href="{LINE_URL}" class="fab-line" target="_blank" rel="noopener" aria-label="加 LINE 私訊">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M19.365 9.863c.349 0 .63.285.63.631 0 .345-.281.63-.63.63H17.61v1.125h1.755c.349 0 .63.283.63.63 0 .344-.281.629-.63.629h-2.386c-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63h2.386c.346 0 .627.285.627.63 0 .349-.281.63-.63.63H17.61v1.125h1.755zm-3.855 3.016c0 .27-.174.51-.432.596-.064.021-.133.031-.199.031-.211 0-.391-.09-.51-.25l-2.443-3.317v2.94c0 .344-.279.629-.631.629-.346 0-.626-.285-.626-.629V8.108c0-.27.173-.51.43-.595.06-.023.136-.033.194-.033.195 0 .375.104.495.254l2.462 3.33V8.108c0-.345.282-.63.63-.63.345 0 .63.285.63.63v4.771zm-5.741 0c0 .344-.282.629-.631.629-.345 0-.627-.285-.627-.629V8.108c0-.345.282-.63.63-.63.346 0 .628.285.628.63v4.771zm-2.466.629H4.917c-.345 0-.63-.285-.63-.629V8.108c0-.345.285-.63.63-.63.348 0 .63.285.63.63v4.141h1.756c.348 0 .629.283.629.63 0 .344-.282.629-.629.629M24 10.314C24 4.943 18.615.572 12 .572S0 4.943 0 10.314c0 4.811 4.27 8.842 10.035 9.608.391.082.923.258 1.058.59.12.301.079.766.038 1.08l-.164 1.02c-.045.301-.24 1.186 1.049.645 1.291-.539 6.916-4.078 9.436-6.975C23.176 14.393 24 12.458 24 10.314"/>
      </svg>
    </a>
    <a href="tel:{PHONE}" class="fab-phone" aria-label="撥打電話">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/>
      </svg>
    </a>
  </div>

</body>
</html>
```

## 主標題 highlight 寫法

主標題可以拆兩段，後半段用螢光筆黃色標亮：

- `借戶籍` + `避雷清單`（highlight）
- `遺產稅` + `免稅額懶人包`（highlight)

判斷拆點：前半是「主題詞」、後半是「動作／結論」→ 後半 highlight。語意分不開就整個 highlight。

## 單張 point-card 寫法

**基本款**（含章節圖示）：

```html
<div class="point-card">
  <div class="point-icon">
    <svg viewBox="0 0 24 24"><!-- 依章節主題畫簡單線條 icon：盾牌/計算機/旗子/鬧鐘/天秤… --></svg>
  </div>
  <div class="point-number">01</div>
  <span class="point-number-bar"></span>
  <div class="point-title">{重點標題}</div>
  <div class="point-body">
    {重點說明文字。}
  </div>
</div>
```

**編號規則**：`01 02 03 04`（兩位數，前面補零）。

**有條列項目**：`<ul><li>` 放在 point-body 裡，關鍵詞用 `<strong>`（自動變品牌色），一張卡 strong 不超過 4 處。⚠️ 每個 `<li>` 都要句號結尾。

**有情境舉例**：

```html
<div class="point-example">
  系統不看你「實際上有沒有收租」，只看「設籍的人是不是你的直系親屬」。
</div>
```

## 結論金句寫法

用 `<span class="accent">` 標 1-2 組對比字（金黃色），標太多會散掉：

```html
<div class="conclusion">
  你以為只是<span class="accent">幫忙</span>，稅務會當成<span class="accent">交易</span>。
</div>
```

## 關鍵數字視覺化（挑最有感的 1-2 個做）

- **對比長條**：兩條不同長度的色條（例：成交價 vs 銀行鑑價），落差用品牌色標出。
- **時間軸／流程點**：圓點＋連接線（例：簽約→對保→撥款）。
- 全部用內嵌 SVG / HTML+CSS，配色沿用整頁色系。

## 寫作小提醒

1. **副標**：不要直接複製影片標題，寫承接句，句號結尾。
2. **引言**：1-2 句，接住「為什麼要看這份」的心情。
3. **結論**：盡量用影片裡的金句。
4. **重點卡片**：3-5 張，不超過 6 張。
5. **emoji**：標題、卡片內文不用 emoji，只有 `.point-example::before` 的 💡 是 CSS 預設。
